"""
THK VTS Configurator バックエンド
FastAPI アプリケーションエントリーポイント
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import auth, configurator, products, i18n
from app.core.config import settings
from app.core.database import Base, engine

from app.core.logger import setup_logging
import logging

setup_logging()

logger = logging.getLogger(__name__)

# データベーステーブルを作成
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="THK VTS Configurator API",
    description="THK 次世代リニア搬送システム API",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS設定
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ルーターを登録
app.include_router(auth.router, prefix="/api/v1/auth", tags=["認証"])
# app.include_router(configurator.router, prefix="/api/v1/configurator", tags=["コンフィギュレーター"])
# app.include_router(products.router, prefix="/api/v1/products", tags=["製品"])
# app.include_router(i18n.router, prefix="/api/v1/i18n", tags=["国際化"])

# ユーザー管理ルーター（インポートが必要）
from app.api import users
app.include_router(users.router, prefix="/api/v1/users", tags=["ユーザー管理"])


@app.get("/")
async def root():
    """ルートパス"""
    return {"message": "THK 次世代リニア搬送システム API", "version": "2.0.0"}


@app.get("/health")
async def health_check():
    """ヘルスチェック"""
    return {"status": "healthy"}


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """グローバル例外処理"""
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "message": str(exc)},
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
    logger.info("FastAPI アプリケーションが起動しました")
