"""
验证令牌模型
用于密码重置和用户注册验证
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from datetime import datetime, timedelta
from app.core.database import Base
import enum


class TokenType(str, enum.Enum):
    """令牌类型枚举"""
    PASSWORD_RESET = "password_reset"  # 密码重置
    USER_REGISTRATION = "user_registration"  # 用户注册


class VerificationToken(Base):
    """验证令牌模型"""
    __tablename__ = "verification_tokens"

    id = Column(Integer, primary_key=True, index=True)
    token = Column(String(255), unique=True, index=True, nullable=False)  # 令牌字符串
    token_type = Column(String(50), nullable=False, index=True)  # 令牌类型
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)  # 关联用户（注册时可能为空）
    email = Column(String(100), nullable=False, index=True)  # 邮箱地址

    username = Column(String(50), nullable=True, index=True)
    
    # 过期时间
    expires_at = Column(DateTime(timezone=True), nullable=False)
    is_used = Column(Boolean, default=False, nullable=False)  # 是否已使用
    
    # 时间戳
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    used_at = Column(DateTime(timezone=True), nullable=True)  # 使用时间
    
    # 关系
    user = relationship("User", foreign_keys=[user_id])

    def is_valid(self) -> bool:
        """检查令牌是否有效"""
        if self.is_used:
            return False
        if datetime.utcnow() > self.expires_at.replace(tzinfo=None):
            return False
        return True

    def __repr__(self):
        return f"<VerificationToken(id={self.id}, token_type={self.token_type}, email={self.email})>"
