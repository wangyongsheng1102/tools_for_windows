"""
产品模型
"""
from sqlalchemy import Column, Integer, String, JSON, DateTime, Boolean, Text, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from app.core.database import Base


class ProductType(str, enum.Enum):
    """产品类型枚举"""
    VTS1 = "vts1"
    VTS2 = "vts2"
    VTS3 = "vts3"
    CUSTOM = "custom"


class Product(Base):
    """产品模型"""
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    product_code = Column(String(50), unique=True, index=True, nullable=False)  # 产品代码
    product_type = Column(Enum(ProductType), nullable=False, index=True)
    name_ja = Column(String(200), nullable=False)  # 日语名称
    name_en = Column(String(200), nullable=False)  # 英语名称
    description_ja = Column(Text, nullable=True)  # 日语描述
    description_en = Column(Text, nullable=True)  # 英语描述
    
    # 产品规格和参数定义
    specifications = Column(JSON, nullable=True)  # 产品规格（JSON格式）
    parameter_definitions = Column(JSON, nullable=True)  # 参数定义（JSON格式，定义可配置的参数）
    
    # 状态
    is_active = Column(Boolean, default=True, nullable=False)
    is_available = Column(Boolean, default=True, nullable=False)  # 是否可用
    
    # 时间戳
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    
    # 关系
    configurations = relationship("Configuration", back_populates="product")

    def __repr__(self):
        return f"<Product(id={self.id}, product_code={self.product_code}, type={self.product_type})>"
