"""
配置模型
"""
from sqlalchemy import Column, Integer, String, JSON, DateTime, ForeignKey, Enum, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum
from app.core.database import Base


class ConfigurationStatus(str, enum.Enum):
    """配置状态枚举"""
    DRAFT = "draft"  # 草稿
    PENDING = "pending"  # 待审核
    APPROVED = "approved"  # 已批准
    REJECTED = "rejected"  # 已拒绝
    ARCHIVED = "archived"  # 已归档


class Configuration(Base):
    """配置模型"""
    __tablename__ = "configurations"

    id = Column(Integer, primary_key=True, index=True)
    configuration_id = Column(String(100), unique=True, index=True, nullable=False)  # 配置ID（对外暴露）
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    product_type = Column(String(50), nullable=False, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=True)  # 关联产品
    
    # 配置数据
    parameters = Column(JSON, nullable=False)  # 配置参数（JSON格式）
    result = Column(JSON, nullable=True)  # 配置结果（JSON格式）
    
    # 状态和元数据
    status = Column(Enum(ConfigurationStatus), default=ConfigurationStatus.DRAFT, nullable=False)
    language = Column(String(10), default="ja", nullable=False)  # 配置时使用的语言
    
    # 备注和描述
    name = Column(String(200), nullable=True)  # 配置名称
    description = Column(Text, nullable=True)  # 配置描述
    notes = Column(Text, nullable=True)  # 备注
    
    # 时间戳
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    approved_at = Column(DateTime(timezone=True), nullable=True)  # 批准时间
    archived_at = Column(DateTime(timezone=True), nullable=True)  # 归档时间
    
    # 关系
    owner = relationship("User", back_populates="configurations")
    product = relationship("Product", back_populates="configurations")

    def __repr__(self):
        return f"<Configuration(id={self.id}, configuration_id={self.configuration_id}, status={self.status})>"
