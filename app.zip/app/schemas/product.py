"""
产品相关的Pydantic模式
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime
from app.models.product import ProductType


class ProductResponse(BaseModel):
    """产品响应模式"""
    id: int
    product_code: str
    product_type: ProductType
    name_ja: str
    name_en: str
    description_ja: Optional[str] = None
    description_en: Optional[str] = None
    specifications: Optional[Dict[str, Any]] = None
    parameter_definitions: Optional[Dict[str, Any]] = None
    is_active: bool
    is_available: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ProductListResponse(BaseModel):
    """产品列表响应模式"""
    total: int
    items: List[ProductResponse]
