"""
参数相关的Pydantic模式
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from datetime import datetime


class ParameterResponse(BaseModel):
    """参数响应模式"""
    id: int
    product_id: int
    parameter_key: str
    parameter_name_ja: str
    parameter_name_en: str
    parameter_type: str
    default_value: Optional[Any] = None
    validation_rules: Optional[Dict[str, Any]] = None
    options: Optional[Dict[str, Any]] = None
    description_ja: Optional[str] = None
    description_en: Optional[str] = None
    unit: Optional[str] = None
    order: int
    is_required: bool
    is_active: bool

    class Config:
        from_attributes = True


class ParameterValueCreate(BaseModel):
    """参数值创建模式"""
    parameter_id: int
    value: Any = Field(..., description="参数值")
