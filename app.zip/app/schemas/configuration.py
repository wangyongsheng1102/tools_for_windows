"""
配置相关的Pydantic模式
"""
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List
from datetime import datetime
from app.models.configuration import ConfigurationStatus


class ConfigurationBase(BaseModel):
    """配置基础模式"""
    product_type: str = Field(..., min_length=1, max_length=50)
    parameters: Dict[str, Any] = Field(..., description="配置参数")
    language: str = Field("ja", pattern="^(ja|en)$")
    name: Optional[str] = Field(None, max_length=200)
    description: Optional[str] = None
    notes: Optional[str] = None


class ConfigurationCreate(ConfigurationBase):
    """创建配置模式"""
    pass


class ConfigurationUpdate(BaseModel):
    """更新配置模式"""
    product_type: Optional[str] = Field(None, min_length=1, max_length=50)
    parameters: Optional[Dict[str, Any]] = None
    name: Optional[str] = Field(None, max_length=200)
    description: Optional[str] = None
    notes: Optional[str] = None
    status: Optional[ConfigurationStatus] = None


class ConfigurationResponse(ConfigurationBase):
    """配置响应模式"""
    id: int
    configuration_id: str
    user_id: int
    product_id: Optional[int] = None
    result: Optional[Dict[str, Any]] = None
    status: ConfigurationStatus
    created_at: datetime
    updated_at: datetime
    approved_at: Optional[datetime] = None
    archived_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class ConfigurationListResponse(BaseModel):
    """配置列表响应模式"""
    total: int
    page: int
    page_size: int
    items: List[ConfigurationResponse]
