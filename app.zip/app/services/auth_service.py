"""
认证服务
处理用户注册、密码重置等认证相关业务逻辑
"""
from sqlalchemy.orm import Session
from typing import Optional
from datetime import datetime, timedelta
from app.models.user import User, UserRole
from app.models.verification_token import VerificationToken, TokenType
from app.core.security import (
    get_password_hash,
    verify_password,
    generate_verification_token,
    create_verification_token_expiry,
    validate_password,
)
from app.core.email import email_service

import logging

logger = logging.getLogger(__name__)


class AuthService:
    """认证业务逻辑服务"""
    
    @staticmethod
    def get_user_by_email(db: Session, email: str) -> Optional[User]:
        """根据邮箱获取用户"""
        return db.query(User).filter(User.email == email).first()
    
    @staticmethod
    def get_user_by_username(db: Session, username: str) -> Optional[User]:
        """根据用户名获取用户"""
        return db.query(User).filter(User.username == username).first()
    
    @staticmethod
    async def request_password_reset(db: Session, email: str, language: str = "ja") -> bool:
        """
        请求密码重置
        1. 检查用户是否存在
        2. 生成重置令牌
        3. 保存到数据库
        4. 发送邮件
        """
        user = AuthService.get_user_by_email(db, email)
        if not user:
            # 为了安全，即使用户不存在也返回成功
            return True
        
        # 生成令牌
        token = generate_verification_token()
        expires_at = create_verification_token_expiry(hours=24)
        
        # 保存令牌
        verification_token = VerificationToken(
            token=token,
            token_type=TokenType.PASSWORD_RESET.value,
            user_id=user.id,
            email=email,
            expires_at=expires_at,
        )
        db.add(verification_token)
        db.commit()
        
        # 发送邮件
        await email_service.send_password_reset_email(email, token, language)
        
        return True
    
    @staticmethod
    async def reset_password(
        db: Session,
        token: str,
        new_password: str
    ) -> Optional[User]:
        """
        重置密码
        1. 验证令牌
        2. 验证密码强度
        3. 更新密码
        4. 标记令牌为已使用
        """
        # 查找令牌
        verification_token = db.query(VerificationToken).filter(
            VerificationToken.token == token,
            VerificationToken.token_type == TokenType.PASSWORD_RESET.value,
            VerificationToken.is_used == False
        ).first()
        
        if not verification_token or not verification_token.is_valid():
            return None
        
        # 验证密码强度
        is_valid, error_msg = validate_password(new_password)
        if not is_valid:
            raise ValueError(error_msg)
        
        # 获取用户
        user = db.query(User).filter(User.id == verification_token.user_id).first()
        if not user:
            return None
        
        # 更新密码
        user.hashed_password = get_password_hash(new_password)
        
        # 标记令牌为已使用
        verification_token.is_used = True
        verification_token.used_at = datetime.utcnow()
        
        db.commit()
        db.refresh(user)
        
        return user
    
    @staticmethod
    async def request_registration(
        db: Session,
        email: str,
        username: str,
        language: str = "ja"
    ) -> bool:
        """
        请求用户注册
        1. 检查邮箱和用户名是否已存在
        2. 生成注册令牌
        3. 保存到数据库（包含username）
        4. 发送邮件
        """
        # 检查邮箱是否已存在
        if AuthService.get_user_by_email(db, email):
            raise ValueError("Email already registered")
        
        # 检查用户名是否已存在
        if AuthService.get_user_by_username(db, username):
            raise ValueError("Username already taken")
        
        # 生成令牌
        token = generate_verification_token()
        expires_at = create_verification_token_expiry(hours=24)
        
        # 保存令牌（包含username，完成注册时使用）
        verification_token = VerificationToken(
            token=token,
            token_type=TokenType.USER_REGISTRATION.value,
            user_id=None,
            email=email,
            username=username,  # 存储用户名
            expires_at=expires_at,
        )
        db.add(verification_token)
        db.commit()
        
        # 发送邮件
        await email_service.send_registration_email(email, username, token, language)
        
        return True
    
    @staticmethod
    async def complete_registration(
        db: Session,
        token: str,
        password: str
    ) -> User:
        """
        完成用户注册
        1. 验证令牌
        2. 验证密码强度
        3. 创建用户
        4. 标记令牌为已使用
        """
        # 查找令牌
        verification_token = db.query(VerificationToken).filter(
            VerificationToken.token == token,
            VerificationToken.token_type == TokenType.USER_REGISTRATION.value,
            VerificationToken.is_used == False
        ).first()
        
        if not verification_token or not verification_token.is_valid():
            raise ValueError("Invalid or expired registration token")
        
        # 检查邮箱是否已被注册
        if AuthService.get_user_by_email(db, verification_token.email):
            raise ValueError("Email already registered")
        
        # 验证密码强度
        is_valid, error_msg = validate_password(password)
        if not is_valid:
            raise ValueError(error_msg)
        
        # 从令牌中获取用户名
        if not verification_token.username:
            raise ValueError("Registration token is missing username")
        
        username = verification_token.username
        
        # 再次检查用户名是否已被使用（防止并发问题）
        if AuthService.get_user_by_username(db, username):
            raise ValueError("Username already taken")
        
        # 创建用户
        user = User(
            email=verification_token.email,
            username=username,
            hashed_password=get_password_hash(password),
            role=UserRole.GUEST,
            is_active=True,
            is_verified=True,
            language="ja",
        )
        db.add(user)
        
        # 关联令牌到用户
        verification_token.user_id = user.id
        verification_token.is_used = True
        verification_token.used_at = datetime.utcnow()
        
        db.commit()
        db.refresh(user)
        
        return user
    
    @staticmethod
    def change_password(
        db: Session,
        user: User,
        current_password: str,
        new_password: str
    ) -> User:
        """
        修改密码
        1. 验证当前密码
        2. 验证新密码强度
        3. 更新密码
        """
        # 验证当前密码
        if not verify_password(current_password, user.hashed_password):
            raise ValueError("Current password is incorrect")
        
        # 验证新密码强度
        is_valid, error_msg = validate_password(new_password)
        if not is_valid:
            raise ValueError(error_msg)
        
        # 更新密码
        user.hashed_password = get_password_hash(new_password)
        db.commit()
        db.refresh(user)
        
        return user
