"""
メール送信機能
"""
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Template
from typing import Optional
from app.core.config import settings

import logging

logger = logging.getLogger(__name__)


class EmailService:
    """メールサービス"""

    def __init__(self):
        self.smtp_host = settings.SMTP_HOST
        self.smtp_port = settings.SMTP_PORT
        self.smtp_user = settings.SMTP_USER
        self.smtp_password = settings.SMTP_PASSWORD
        self.from_email = settings.FROM_EMAIL or settings.SMTP_USER
        self.base_url = settings.BASE_URL
        self.use_tls = settings.SMTP_USE_TLS

    async def send_email(
            self,
            to_email: str,
            subject: str,
            html_content: str,
            text_content: Optional[str] = None
    ) -> bool:
        """
        メールを送信
        """
        try:
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.from_email
            message["To"] = to_email

            # テキストとHTMLコンテンツを追加
            if text_content:
                text_part = MIMEText(text_content, "plain", "utf-8")
                message.attach(text_part)

            html_part = MIMEText(html_content, "html", "utf-8")
            message.attach(html_part)

            # メールを送信
            await aiosmtplib.send(
                message,
                hostname=self.smtp_host,
                port=self.smtp_port,
                username=self.smtp_user,
                password=self.smtp_password,
                use_tls=self.use_tls,
            )
            return True
        except Exception as e:
            print(f"Error sending email: {str(e)}")
            return False

    async def send_password_reset_email(self, email: str, reset_token: str, language: str = "ja") -> bool:
        """パスワードリセットメールを送信"""
        reset_url = f"{self.base_url}/reset-password?token={reset_token}"

        if language == "ja":
            subject = "パスワードリセットのご案内"
            html_template = """
            <html>
            <body>
                <h2>パスワードリセットのご案内</h2>
                <p>以下のリンクをクリックしてパスワードをリセットしてください。</p>
                <p><a href="{{ reset_url }}">パスワードをリセット</a></p>
                <p>このリンクは24時間有効です。</p>
                <p>このメールに心当たりがない場合は、無視してください。</p>
            </body>
            </html>
            """
            text_content = f"パスワードリセット: {reset_url}"
        else:
            subject = "Password Reset Request"
            html_template = """
            <html>
            <body>
                <h2>Password Reset Request</h2>
                <p>Please click the link below to reset your password.</p>
                <p><a href="{{ reset_url }}">Reset Password</a></p>
                <p>This link is valid for 24 hours.</p>
                <p>If you did not request this, please ignore this email.</p>
            </body>
            </html>
            """
            text_content = f"Password Reset: {reset_url}"

        template = Template(html_template)
        html_content = template.render(reset_url=reset_url)

        return await self.send_email(email, subject, html_content, text_content)

    async def send_registration_email(self, email: str, username: str, registration_token: str,
                                      language: str = "ja") -> bool:
        """ユーザー登録メールを送信"""
        registration_url = f"{self.base_url}/complete-registration?token={registration_token}"

        if language == "ja":
            subject = "ユーザー登録のご案内"
            html_template = """
            <html>
            <body>
                <h2>ユーザー登録のご案内</h2>
                <p>ユーザー名: {{ username }}</p>
                <p>以下のリンクをクリックしてパスワードを設定し、登録を完了してください。</p>
                <p><a href="{{ registration_url }}">登録を完了</a></p>
                <p>このリンクは24時間有効です。</p>
            </body>
            </html>
            """
            text_content = f"ユーザー登録: {registration_url}"
        else:
            subject = "User Registration"
            html_template = """
            <html>
            <body>
                <h2>User Registration</h2>
                <p>Username: {{ username }}</p>
                <p>Please click the link below to set your password and complete registration.</p>
                <p><a href="{{ registration_url }}">Complete Registration</a></p>
                <p>This link is valid for 24 hours.</p>
            </body>
            </html>
            """
            text_content = f"User Registration: {registration_url}"

        template = Template(html_template)
        html_content = template.render(username=username, registration_url=registration_url)

        return await self.send_email(email, subject, html_content, text_content)


# グローバルなメールサービスインスタンスを作成
email_service = EmailService()
