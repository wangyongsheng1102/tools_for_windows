"""
データベース接続とセッション管理
"""
from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from app.core.config import settings

# データベースエンジンを作成
engine = create_engine(
    settings.DATABASE_URL,
    connect_args={
        # "options": f"-c search_path={settings.DEFAULT_SCHEMA}"  # 如果配置了 DEFAULT_SCHEMA
        # 或者直接指定
        "options": "-c search_path=vts"
    },
    pool_pre_ping=True,
    pool_size=10,
    max_overflow=20,
    echo=True,  # Trueに設定するとSQLログを確認できます
)

# セッションファクトリを作成
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ベースモデルクラスを作成
Base = declarative_base()
Base.metadata.schema = 'vts'


def get_db():
    """
    データベースセッションを取得
    依存性注入に使用
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
