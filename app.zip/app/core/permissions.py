"""
権限制御
"""
from functools import wraps
from typing import List, Optional
from fastapi import HTTPException, status, Depends
from sqlalchemy.orm import Session
from app.core.database import get_db
from app.models.user import User, UserRole
from app.models.configuration import Configuration
from app.core.security import decode_token
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> User:
    """現在のユーザーを取得"""
    token = credentials.credentials
    payload = decode_token(token)
    user_id: int = payload.get("sub")
    
    if user_id is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="認証情報が無効です",
        )
    
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="ユーザーが見つかりません",
        )
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="ユーザーは無効化されています",
        )
    
    return user


def require_roles(allowed_roles: List[UserRole]):
    """特定のロールを要求するデコレータ"""
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            current_user: User = kwargs.get("current_user")
            if not current_user:
                # argsから取得を試みる
                for arg in args:
                    if isinstance(arg, User):
                        current_user = arg
                        break
            
            if not current_user:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="認証が必要です",
                )
            
            if current_user.role not in allowed_roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"必要なロール: {[role.value for role in allowed_roles]}",
                )
            
            return await func(*args, **kwargs)
        return wrapper
    return decorator


def check_permission(user: User, resource: str, action: str) -> bool:
    """
    ユーザーの権限をチェック
    resource: リソースタイプ (configuration, user, product, etc.)
    action: 操作タイプ (create, read, update, delete, approve, etc.)
    """
    # 管理者はすべての権限を持つ
    if user.role == UserRole.ADMIN:
        return True
    
    # エンジニアは設定の作成、読み取り、更新が可能
    if user.role == UserRole.ENGINEER:
        if resource == "configuration":
            return action in ["create", "read", "update", "delete"]
        if resource == "product":
            return action in ["read"]
    
    # 閲覧者は読み取りのみ可能
    if user.role == UserRole.VIEWER:
        return action == "read"
    
    # ゲストは公開リソースの読み取りのみ可能
    if user.role == UserRole.GUEST:
        return action == "read" and resource == "product"
    
    return False


def check_ownership(user: User, resource: Configuration) -> bool:
    """リソースの所有権をチェック"""
    if user.role == UserRole.ADMIN:
        return True
    return resource.user_id == user.id
