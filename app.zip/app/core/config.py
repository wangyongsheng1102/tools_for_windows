"""
应用配置
"""
import secrets

from pydantic import Field
from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # CORS設定
    CORS_ORIGINS: List[str] = Field(..., env="CORS_ORIGINS")

    # API設定
    API_V1_PREFIX: str = Field(..., env="API_V1_PREFIX")

    # データベース設定
    # DATABASE_URL: str = "postgresql://user:password@localhost:5432/thk_configurator"
    DATABASE_URL: str = Field(..., env="DATABASE_URL")

    # JWT設定
    SECRET_KEY: str = secrets.token_urlsafe(32)
    ALGORITHM: str = Field(..., env="ALGORITHM")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(..., env="ACCESS_TOKEN_EXPIRE_MINUTES")
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(..., env="REFRESH_TOKEN_EXPIRE_DAYS")

    # パスワード設定
    PASSWORD_MIN_LENGTH: int = Field(..., env="PASSWORD_MIN_LENGTH")
    PASSWORD_REQUIRE_UPPERCASE: bool = Field(..., env="PASSWORD_REQUIRE_UPPERCASE")
    PASSWORD_REQUIRE_LOWERCASE: bool = Field(..., env="PASSWORD_REQUIRE_LOWERCASE")
    PASSWORD_REQUIRE_NUMBER: bool = Field(..., env="PASSWORD_REQUIRE_NUMBER")
    PASSWORD_REQUIRE_SPECIAL: bool = Field(..., env="PASSWORD_REQUIRE_SPECIAL")

    # ページネーション設定
    DEFAULT_PAGE_SIZE: int = Field(..., env="DEFAULT_PAGE_SIZE")
    MAX_PAGE_SIZE: int = Field(..., env="MAX_PAGE_SIZE")

    # メール設定
    SMTP_HOST: str = Field(..., env="SMTP_HOST")
    SMTP_PORT: int = Field(..., env="SMTP_PORT")
    SMTP_USER: str = Field(..., env="SMTP_USER")
    SMTP_PASSWORD: str = Field(..., env="SMTP_PASSWORD")
    SMTP_USE_TLS: bool = Field(..., env="SMTP_USE_TLS")
    FROM_EMAIL: str = Field(..., env="FROM_EMAIL")
    BASE_URL: str = Field(..., env="BASE_URL")  # フロントエンドURL、メールリンク生成用

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
