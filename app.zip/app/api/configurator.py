"""
コンフィギュレーターAPIルート
"""
from fastapi import APIRouter, HTTPException, Depends, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional

from app.core.database import get_db
from app.core.permissions import get_current_user
from app.models.user import User
from app.models.configuration import ConfigurationStatus
from app.schemas.configuration import (
    ConfigurationCreate,
    ConfigurationUpdate,
    ConfigurationResponse,
    ConfigurationListResponse,
)
from app.services.configuration_service import ConfigurationService

router = APIRouter()


@router.post("/create", response_model=ConfigurationResponse, status_code=status.HTTP_201_CREATED)
async def create_configuration(
    request: ConfigurationCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    新規コンフィギュレーションを作成
    認証が必要
    """
    try:
        configuration = ConfigurationService.create_configuration(
            db=db,
            user=current_user,
            product_type=request.product_type,
            parameters=request.parameters,
            language=request.language,
            name=request.name,
            description=request.description,
            notes=request.notes,
        )
        return configuration
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"コンフィギュレーション作成エラー: {str(e)}",
        )


@router.get("/{configuration_id}", response_model=ConfigurationResponse)
async def get_configuration(
    configuration_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    コンフィギュレーションの詳細を取得
    認証が必要
    """
    try:
        configuration = ConfigurationService.get_configuration(
            db=db,
            configuration_id=configuration_id,
            user=current_user
        )
        if not configuration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="コンフィギュレーションが見つかりません",
            )
        return configuration
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )


@router.get("/", response_model=ConfigurationListResponse)
async def list_configurations(
    page: int = Query(1, ge=1, description="ページ番号"),
    page_size: int = Query(20, ge=1, le=100, description="1ページあたりの件数"),
    status: Optional[ConfigurationStatus] = Query(None, description="コンフィギュレーション状態"),
    product_type: Optional[str] = Query(None, description="製品タイプ"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    コンフィギュレーションリストを取得
    認証が必要
    """
    try:
        skip = (page - 1) * page_size
        configurations, total = ConfigurationService.list_configurations(
            db=db,
            user=current_user,
            skip=skip,
            limit=page_size,
            status=status,
            product_type=product_type
        )
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "items": configurations,
        }
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )


@router.put("/{configuration_id}", response_model=ConfigurationResponse)
async def update_configuration(
    configuration_id: str,
    request: ConfigurationUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    コンフィギュレーションを更新
    認証が必要、自分のコンフィギュレーションのみ更新可能
    """
    try:
        configuration = ConfigurationService.get_configuration(
            db=db,
            configuration_id=configuration_id,
            user=current_user
        )
        if not configuration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="コンフィギュレーションが見つかりません",
            )
        
        update_data = request.dict(exclude_unset=True)
        configuration = ConfigurationService.update_configuration(
            db=db,
            configuration=configuration,
            user=current_user,
            update_data=update_data
        )
        return configuration
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )


@router.delete("/{configuration_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_configuration(
    configuration_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    コンフィギュレーションを削除
    認証が必要、自分のコンフィギュレーションのみ削除可能
    """
    try:
        configuration = ConfigurationService.get_configuration(
            db=db,
            configuration_id=configuration_id,
            user=current_user
        )
        if not configuration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="コンフィギュレーションが見つかりません",
            )
        
        ConfigurationService.delete_configuration(
            db=db,
            configuration=configuration,
            user=current_user
        )
        return None
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )


@router.post("/{configuration_id}/approve", response_model=ConfigurationResponse)
async def approve_configuration(
    configuration_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """
    コンフィギュレーションを承認
    管理者権限が必要
    """
    try:
        configuration = ConfigurationService.get_configuration(
            db=db,
            configuration_id=configuration_id,
            user=current_user
        )
        if not configuration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="コンフィギュレーションが見つかりません",
            )
        
        configuration = ConfigurationService.approve_configuration(
            db=db,
            configuration=configuration,
            user=current_user
        )
        return configuration
    except PermissionError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=str(e),
        )
