# API模块
from app.api import auth, configurator, products, i18n, users