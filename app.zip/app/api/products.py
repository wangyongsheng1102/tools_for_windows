"""
製品APIルート
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from typing import Optional

from app.core.database import get_db
from app.models.product import ProductType
from app.schemas.product import ProductResponse, ProductListResponse
from app.services.product_service import ProductService

router = APIRouter()


@router.get("/", response_model=ProductListResponse)
async def list_products(
    product_type: Optional[ProductType] = Query(None, description="製品タイプ"),
    is_active: Optional[bool] = Query(True, description="アクティブかどうか"),
    is_available: Optional[bool] = Query(True, description="利用可能かどうか"),
    db: Session = Depends(get_db)
):
    """
    製品リストを取得
    公開インターフェース、認証不要
    """
    products = ProductService.get_products(
        db=db,
        product_type=product_type,
        is_active=is_active,
        is_available=is_available
    )
    return {
        "total": len(products),
        "items": products,
    }


@router.get("/{product_id}", response_model=ProductResponse)
async def get_product(
    product_id: int,
    db: Session = Depends(get_db)
):
    """
    製品詳細を取得
    公開インターフェース、認証不要
    """
    product = ProductService.get_product_by_id(db, product_id)
    if not product:
        from fastapi import HTTPException, status
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="製品が見つかりません",
        )
    return product


@router.get("/{product_id}/parameters", response_model=dict)
async def get_product_parameters(
    product_id: int,
    db: Session = Depends(get_db)
):
    """
    製品のパラメーター定義を取得
    公開インターフェース、認証不要
    """
    parameters = ProductService.get_parameter_definitions(db, product_id)
    if parameters is None:
        from fastapi import HTTPException, status
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="製品が見つかりません",
        )
    return {"parameters": parameters}
