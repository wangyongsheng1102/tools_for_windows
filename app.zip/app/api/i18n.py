"""
国际化API路由
"""
from fastapi import APIRouter
from typing import Dict

router = APIRouter()


@router.get("/translations/{language}")
async def get_translations(language: str) -> Dict[str, str]:
    """
    指定言語の翻訳テキストを取得
language: ja (日本語) または en (英語)
    """
    # TODO: PDFドキュメントから抽出した日英対照表を使用して翻訳ファイルを作成
    translations = {
        "ja": {
            "app.title": "THK VTS コンフィギュレーター",
            "app.welcome": "ようこそ",
            "configurator.title": "製品設定",
            "configurator.create": "新規作成",
            "configurator.save": "保存",
            "configurator.cancel": "キャンセル",
        },
        "en": {
            "app.title": "THK VTS Configurator",
            "app.welcome": "Welcome",
            "configurator.title": "Product Configuration",
            "configurator.create": "Create New",
            "configurator.save": "Save",
            "configurator.cancel": "Cancel",
        }
    }
    
    return translations.get(language, translations["en"])
