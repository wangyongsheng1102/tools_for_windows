"""
認証関連API
"""
from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    decode_token,
    validate_password,
)
from app.core.config import settings
from app.core.permissions import get_current_user
from app.schemas.user import UserResponse, Token
from app.schemas.auth import (
    LoginRequest,
    PasswordResetRequest,
    PasswordResetConfirm,
    RegistrationRequest,
    RegistrationComplete,
    ChangePasswordRequest,
    UpdateProfileRequest,
    RefreshTokenRequest,
)
from app.models.user import User, UserRole
from app.services.auth_service import AuthService

import logging

logger = logging.getLogger(__name__)

router = APIRouter()


@router.post("/login", response_model=Token)
async def login(
        login_data: LoginRequest,
        db: Session = Depends(get_db)
):
    """
    ユーザーログイン（emailとパスワードを使用）
    成功するとJWTトークンを返す
    """
    # emailでユーザーを検索
    user = AuthService.get_user_by_email(db, login_data.email)

    if not user or not verify_password(login_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="メールアドレスまたはパスワードが正しくありません",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="ユーザーは無効化されています",
        )

    # 最終ログイン時間を更新
    from datetime import datetime
    user.last_login = datetime.utcnow()
    db.commit()

    # トークンを作成
    access_token = create_access_token(data={"sub": user.id, "username": user.username})
    refresh_token = create_refresh_token(data={"sub": user.id, "username": user.username})

    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    }


@router.post("/register/request", status_code=status.HTTP_200_OK)
async def request_registration(
        registration_data: RegistrationRequest,
        db: Session = Depends(get_db)
):
    """
    新規ユーザー登録リクエスト（ステップ1）
    emailとユーザー名を入力し、確認メールを送信
    """
    try:
        await AuthService.request_registration(
            db=db,
            email=registration_data.email,
            username=registration_data.username,
            language="ja"  # リクエストヘッダーまたはパラメータで言語を決定可能
        )
        return {
            "message": "登録メールを送信しました。メールを確認して登録を完了してください。",
            "email": registration_data.email
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"登録メール送信エラー: {str(e)}",
        )


@router.post("/register/complete", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def complete_registration(
        registration_data: RegistrationComplete,
        db: Session = Depends(get_db)
):
    """
    ユーザー登録完了（ステップ2）
    メールリンクからアクセスし、パスワード設定後に登録完了
    """
    try:
        user = await AuthService.complete_registration(
            db=db,
            token=registration_data.token,
            password=registration_data.password
        )
        return user
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"登録完了エラー: {str(e)}",
        )


@router.post("/password/reset/request", status_code=status.HTTP_200_OK)
async def request_password_reset(
        reset_data: PasswordResetRequest,
        db: Session = Depends(get_db)
):
    """
    パスワードリセットリクエスト（ステップ1）
    メールアドレスを入力し、パスワードリセットメールを送信
    """
    try:
        await AuthService.request_password_reset(
            db=db,
            email=reset_data.email,
            language="ja"  # リクエストヘッダーまたはパラメータで言語を決定可能
        )
        # セキュリティのため、ユーザーが存在しない場合も成功メッセージを返す
        return {
            "message": "メールアドレスが存在する場合、パスワードリセットリンクが送信されました。",
            "email": reset_data.email
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"パスワードリセットメール送信エラー: {str(e)}",
        )


@router.post("/password/reset/confirm", status_code=status.HTTP_200_OK)
async def confirm_password_reset(
        reset_data: PasswordResetConfirm,
        db: Session = Depends(get_db)
):
    """
    パスワードリセット確認（ステップ2）
    メールリンクからアクセスし、新しいパスワードを入力してリセット
    """
    try:
        user = await AuthService.reset_password(
            db=db,
            token=reset_data.token,
            new_password=reset_data.new_password
        )
        if not user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="無効または期限切れのリセットトークンです",
            )
        return {
            "message": "パスワードが正常にリセットされました",
            "user_id": user.id
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"パスワードリセットエラー: {str(e)}",
        )


@router.post("/refresh", response_model=Token)
async def refresh_token(
        token_data: RefreshTokenRequest,
        db: Session = Depends(get_db)
):
    """
    アクセストークンをリフレッシュ
    リクエストボディ: {"refresh_token": "token-string"}
    """
    payload = decode_token(token_data.refresh_token)

    if payload.get("type") != "refresh":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="無効なトークンタイプです",
        )

    user_id = payload.get("sub")
    user = db.query(User).filter(User.id == user_id).first()

    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="ユーザーが見つからないか、無効化されています",
        )

    # 新しいトークンを作成
    access_token = create_access_token(data={"sub": user.id, "username": user.username})
    new_refresh_token = create_refresh_token(data={"sub": user.id, "username": user.username})

    return {
        "access_token": access_token,
        "refresh_token": new_refresh_token,
        "token_type": "bearer",
        "expires_in": settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    }


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(current_user: User = Depends(get_current_user)):
    """
    現在のユーザー情報を取得
    """
    return current_user


@router.put("/me", response_model=UserResponse)
async def update_profile(
        profile_data: UpdateProfileRequest,
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
):
    """
    プロフィールを更新（ユーザー名、フルネーム、言語）
    """
    update_data = profile_data.dict(exclude_unset=True)

    # ユーザー名を更新する場合、既に使用されていないかチェック
    if "username" in update_data and update_data["username"] != current_user.username:
        existing_user = AuthService.get_user_by_username(db, update_data["username"])
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="このユーザー名は既に使用されています",
            )

    for field, value in update_data.items():
        setattr(current_user, field, value)

    db.commit()
    db.refresh(current_user)

    return current_user


@router.post("/password/change", status_code=status.HTTP_200_OK)
async def change_password(
        password_data: ChangePasswordRequest,
        current_user: User = Depends(get_current_user),
        db: Session = Depends(get_db)
):
    """
    パスワードを変更
    現在のパスワードと新しいパスワードを入力する必要があります
    """
    try:
        AuthService.change_password(
            db=db,
            user=current_user,
            current_password=password_data.current_password,
            new_password=password_data.new_password
        )
        return {
            "message": "パスワードが正常に変更されました"
        }
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"パスワード変更エラー: {str(e)}",
        )
