using System;
using ImageMagick;

namespace PdfDiffTool.Services;

public class ImageComparer
{
    public static bool CompareImages(string imgA, string imgB, double threshold, 
                            out double difference, string? diffOutput = null)
    {
        using var imageA = new MagickImage(imgA);
        using var imageB = new MagickImage(imgB);

        if (imageA.Width != imageB.Width || imageA.Height != imageB.Height)
        {
            difference = 1.0;
            return false;
        }

        // Magick.NET's Compare signature returns the diff image and outputs
        // the numeric difference via an out double. Use that shape.
        using var diffImage = imageA.Compare(imageB, ErrorMetric.RootMeanSquared, out difference);
        if (diffImage is null)
            throw new InvalidOperationException("diffImage cannot be null.");
        if (diffOutput != null)
        {
            // 增强差异图可视化
            diffImage.Modulate(new Percentage(150), new Percentage(150));
            diffImage.Write(diffOutput);
        }

        return difference <= threshold;
    }
}
