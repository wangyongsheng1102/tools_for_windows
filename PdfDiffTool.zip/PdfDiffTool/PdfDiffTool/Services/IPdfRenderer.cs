using PdfDiffTool.Models;

namespace PdfDiffTool.Services;

public interface IPdfRenderer
{
    CompareResult Compare(string pdfA, string pdfB, int dpi, double threshold, string workDir);
}
