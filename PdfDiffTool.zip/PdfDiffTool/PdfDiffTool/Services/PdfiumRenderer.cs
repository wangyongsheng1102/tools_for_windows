using PdfiumViewer;
using ImageMagick;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using PdfDiffTool.Models;
using System.Linq;
using System;

namespace PdfDiffTool.Services;

using System.Runtime.Versioning;

[SupportedOSPlatform("windows")]
public class PdfiumRenderer : IPdfRenderer
{
    public CompareResult Compare(string pdfA, string pdfB, int dpi, double threshold, string workDir)
    {
        var result = new CompareResult { WorkDir = workDir };

        using var docA = PdfDocument.Load(pdfA);
        using var docB = PdfDocument.Load(pdfB);

        int pagesA = docA.PageCount;
        int pagesB = docB.PageCount;

        if (pagesA != pagesB)
        {
            result.AllEqual = false;
            result.DifferentPages = Enumerable.Range(1, Math.Max(pagesA, pagesB)).ToList();
            return result;
        }

        var dirA = Path.Combine(workDir, "A");
        var dirB = Path.Combine(workDir, "B");
        var dirDiff = Path.Combine(workDir, "Diff");
        Directory.CreateDirectory(dirA);
        Directory.CreateDirectory(dirB);
        Directory.CreateDirectory(dirDiff);

        for (int i = 0; i < pagesA; i++)
        {
            var imgA = RenderPage(docA, i, dpi, dirA);
            var imgB = RenderPage(docB, i, dpi, dirB);
            
            var comparer = new ImageComparer();
            var equal = ImageComparer.CompareImages(imgA, imgB, threshold, out double diff, 
                                             Path.Combine(dirDiff, $"page_{i+1:000}_diff.png"));
            
            if (!equal)
            {
                result.DifferentPages.Add(i + 1);
                result.DiffImagePaths[i + 1] = Path.Combine(dirDiff, $"page_{i+1:000}_diff.png");
            }
        }

        result.AllEqual = result.DifferentPages.Count == 0;
        return result;
    }

    CompareResult IPdfRenderer.Compare(string pdfA, string pdfB, int dpi, double threshold, string workDir)
    {
        return Compare(pdfA, pdfB, dpi, threshold, workDir);
    }

    private string RenderPage(PdfDocument doc, int pageIndex, int dpi, string outputDir)
    {
        using var pageImage = doc.Render(pageIndex, dpi, dpi, PdfRenderFlags.CorrectFromDpi);
        var fileName = $"page_{pageIndex + 1:000}.png";
        var filePath = Path.Combine(outputDir, fileName);
        
        pageImage.Save(filePath, ImageFormat.Png);
        return filePath;
    }
}
