using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PdfDiffTool.Services;
using PdfDiffTool.Models;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using Avalonia.Media;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia;
using System.Threading.Tasks;
using System.IO;
using System;
using System.Linq;

namespace PdfDiffTool.ViewModels;

public partial class MainWindowViewModel : ObservableObject
{
    private readonly IPdfRenderer _pdfRenderer;
    private readonly ImageComparer _imageComparer;

    [ObservableProperty]
    private string pdfAPath = "";

    [ObservableProperty]
    private string pdfBPath = "";

    [ObservableProperty]
    private int dpi = 144;

    [ObservableProperty]
    private double threshold = 0.001;

    [ObservableProperty]
    private bool isBusy;

    [ObservableProperty]
    private double progress;

    [ObservableProperty]
    private string statusMessage = "准备就绪";

    [ObservableProperty]
    private string statusBar = "就绪";

    [ObservableProperty]
    private string resultSummary = "";

    [ObservableProperty]
    private IBrush resultColor = Brushes.Transparent;

    [ObservableProperty]
    private ObservableCollection<int> differentPages = new();

    [ObservableProperty]
    private int selectedPage;

    [ObservableProperty]
    private string imageAPath = "";

    [ObservableProperty]
    private string imageBPath = "";

    [ObservableProperty]
    private string imageDiffPath = "";

    public MainWindowViewModel()
    {
        // PdfiumRenderer uses System.Drawing and Pdfium which are Windows-only. Suppress CA1416 here
    #pragma warning disable CA1416
        _pdfRenderer = new PdfiumRenderer();
    #pragma warning restore CA1416
        _imageComparer = new ImageComparer();
        DifferentPages.CollectionChanged += (s, e) => OnPropertyChanged(nameof(HasDifferences));
    }

    public bool CanCompare => !IsBusy && !string.IsNullOrEmpty(PdfAPath) && !string.IsNullOrEmpty(PdfBPath);

    public bool HasDifferences => DifferentPages.Count > 0;

    public bool HasDiffImage => !string.IsNullOrEmpty(ImageDiffPath);

    [RelayCommand]
    private async Task SelectPdfA()
    {
        var lifetime = Application.Current?.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime;
        var main = lifetime?.MainWindow;
        if (main == null)
            return;

#pragma warning disable CS0618 // OpenFileDialog is obsolete on some Avalonia versions; keep for compatibility
        var dialog = new OpenFileDialog { Title = "选择 PDF A" };
        var files = await dialog.ShowAsync(main);
#pragma warning restore CS0618

        if (files?.Length > 0)
            PdfAPath = files[0];
    }

    [RelayCommand]
    private async Task SelectPdfB()
    {
        var lifetime = Application.Current?.ApplicationLifetime as IClassicDesktopStyleApplicationLifetime;
        var main = lifetime?.MainWindow;
        if (main == null)
            return;

#pragma warning disable CS0618
        var dialog = new OpenFileDialog { Title = "选择 PDF B" };
        var files = await dialog.ShowAsync(main);
#pragma warning restore CS0618
        if (files?.Length > 0)
            PdfBPath = files[0];
    }

    [RelayCommand]
    private async Task Compare()
    {
        if (!CanCompare) return;

        IsBusy = true;
        Progress = 0;
        StatusMessage = "正在分析 PDF...";
        DifferentPages.Clear();

        try
        {
            var workDir = Path.Combine(Path.GetTempPath(), "PdfDiffTemp");
            Directory.CreateDirectory(workDir);

            var result = await Task.Run(() => _pdfRenderer.Compare(
                PdfAPath, PdfBPath, Dpi, Threshold, workDir));

            Progress = 100;

            if (result.AllEqual)
            {
                ResultSummary = "✅ 两个 PDF 完全一致";
                ResultColor = Brushes.Green;
            }
            else
            {
                ResultSummary = $"❌ 发现 {result.DifferentPages.Count} 页差异";
                ResultColor = Brushes.Red;
                foreach (var page in result.DifferentPages)
                    DifferentPages.Add(page);
            }

            SelectedPage = DifferentPages.FirstOrDefault();
            LoadPreviewImages(result);
        }
        catch (Exception ex)
        {
            ResultSummary = $"❌ 比较失败: {ex.Message}";
            ResultColor = Brushes.Red;
        }
        finally
        {
            IsBusy = false;
        }
    }

    partial void OnSelectedPageChanged(int value)
    {
        LoadPreviewImagesForPage(value);
    }

    private void LoadPreviewImages(CompareResult result)
    {
        if (result.DiffImagePaths.TryGetValue(SelectedPage, out var diffPath))
        {
            ImageDiffPath = diffPath;
            ImageAPath = Path.Combine(result.WorkDir, "A", $"page_{SelectedPage:000}.png");
            ImageBPath = Path.Combine(result.WorkDir, "B", $"page_{SelectedPage:000}.png");
        }
    }

    private void LoadPreviewImagesForPage(int page)
    {
        ImageDiffPath = "";
        ImageAPath = "";
        ImageBPath = "";
    }
}
