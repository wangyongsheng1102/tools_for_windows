using System.Collections.Generic;

namespace PdfDiffTool.Models;

public class CompareResult
{
    public bool AllEqual { get; set; }
    public List<int> DifferentPages { get; set; } = new();
    public Dictionary<int, string> DiffImagePaths { get; set; } = new();
    public string WorkDir { get; set; } = "";
}
