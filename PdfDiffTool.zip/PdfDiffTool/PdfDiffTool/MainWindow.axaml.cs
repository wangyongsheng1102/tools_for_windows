using Avalonia.Controls;

namespace PdfDiffTool;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        // Set runtime DataContext so bindings (commands/properties) work.
        DataContext = new ViewModels.MainWindowViewModel();
    }
}