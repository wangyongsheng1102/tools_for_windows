using Avalonia.Media.Imaging;
using ReactiveUI;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using ExcelImageCompareTool.Models;
using ExcelImageCompareTool.Services;
using System.Linq;

namespace ExcelImageCompareTool.ViewModels
{
    public class AppConfig
    {
        public string LastExcelPath { get; set; } = "";
        public string LastSheet { get; set; } = "Sheet1";
        public int OldCol { get; set; } = 2;
        public int NewCol { get; set; } = 16;
        public int MaxDegree { get; set; } = 4;
    }

    public class MainWindowViewModel : ReactiveObject
    {
        public AppConfig Config { get; set; } = new AppConfig();

        public ObservableCollection<ImageCompareResult> Results { get; } = new();

        private ImageCompareResult? _selectedResult;
        public ImageCompareResult? SelectedResult
        {
            get => _selectedResult;
            set
            {
                this.RaiseAndSetIfChanged(ref _selectedResult, value);
                UpdatePreview();
            }
        }

        private Bitmap? _selectedPreviewImage;
        public Bitmap? SelectedPreviewImage
        {
            get => _selectedPreviewImage;
            set => this.RaiseAndSetIfChanged(ref _selectedPreviewImage, value);
        }

        private readonly ImageCompareService _svc = new ImageCompareService();

        public MainWindowViewModel()
        {
            LoadConfig();
            CompareCommand = ReactiveCommand.CreateFromTask(CompareAsync);
            ExportAllCommand = ReactiveCommand.CreateFromTask(ExportAllAsync);
            ExportSingleCommand = ReactiveCommand.CreateFromTask<object>(ExportSingleAsync);
            PreviewCommand = ReactiveCommand.CreateFromTask<object>(PreviewAsync);
        }

        public IReactiveCommand CompareCommand { get; }
        public IReactiveCommand ExportAllCommand { get; }
        public IReactiveCommand ExportSingleCommand { get; }
        public IReactiveCommand PreviewCommand { get; }

        public async Task InitializeAsync()
        {
            await Task.CompletedTask;
        }

        public void LoadConfig()
        {
            if (File.Exists("config.json"))
            {
                try { Config = JsonSerializer.Deserialize<AppConfig>(File.ReadAllText("config.json")) ?? new AppConfig(); }
                catch { Config = new AppConfig(); }
            }
        }

        public void SaveConfig() => File.WriteAllText("config.json", JsonSerializer.Serialize(Config));

        public async Task CompareAsync()
        {
            if (string.IsNullOrWhiteSpace(Config.LastExcelPath) || !File.Exists(Config.LastExcelPath))
                return;

            var oldDic = ExcelImageService.ExtractColumnImages(Config.LastExcelPath, Config.LastSheet, Config.OldCol);
            var newDic = ExcelImageService.ExtractColumnImages(Config.LastExcelPath, Config.LastSheet, Config.NewCol);

            var rows = oldDic.Keys.Union(newDic.Keys).OrderBy(r => r).ToList();

            var items = rows.Select(r =>
            {
                oldDic.TryGetValue(r, out var ob);
                newDic.TryGetValue(r, out var nb);
                return (RowIndex: r, OldImage: ob ?? Array.Empty<byte>(), NewImage: nb ?? Array.Empty<byte>());
            }).ToList();

            var nonEmpty = items.Where(it => it.OldImage.Length > 0 && it.NewImage.Length > 0).ToList();
            var onlyOld = items.Where(it => it.OldImage.Length > 0 && it.NewImage.Length == 0).ToList();
            var onlyNew = items.Where(it => it.OldImage.Length == 0 && it.NewImage.Length > 0).ToList();

            Results.Clear();

            foreach (var it in onlyOld)
            {
                Results.Add(new ImageCompareResult
                {
                    Row = it.RowIndex,
                    HasOldImage = true,
                    HasNewImage = false,
                    HasDiff = false,
                    RegionCount = 0
                });
            }
            foreach (var it in onlyNew)
            {
                Results.Add(new ImageCompareResult
                {
                    Row = it.RowIndex,
                    HasOldImage = false,
                    HasNewImage = true,
                    HasDiff = false,
                    RegionCount = 0
                });
            }

            var pairs = nonEmpty.Select(it => (it.RowIndex, it.OldImage, it.NewImage)).ToList();

            var compareResults = await _svc.CompareBatchAsync(pairs, Config.MaxDegree);

            foreach (var cr in compareResults)
            {
                var r = new ImageCompareResult
                {
                    Row = cr.RowIndex,
                    HasOldImage = true,
                    HasNewImage = true,
                    HasDiff = cr.HasDiff,
                    RegionCount = cr.Regions.Count,
                    DiffBitmap = cr.DiffBitmap
                };
                Results.Add(r);
            }

            SaveConfig();
        }

        public async Task ExportSingleAsync(object param)
        {
            if (param is ImageCompareResult r && r.DiffBitmap != null)
            {
                var dialog = new Avalonia.Controls.SaveFileDialog();
                dialog.Filters.Add(new Avalonia.Controls.FileDialogFilter { Name = "PNG", Extensions = { "png" } });
                var window = Avalonia.Application.Current!.ApplicationLifetime is Avalonia.Controls.ApplicationLifetimes.IClassicDesktopStyleApplicationLifetime desktop
                    ? desktop.MainWindow : null;

                var path = await dialog.ShowAsync(window);
                if (!string.IsNullOrEmpty(path))
                {
                    r.DiffBitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
        }

        public async Task ExportAllAsync()
        {
            var dlg = new Avalonia.Controls.OpenFolderDialog();
            var window = Avalonia.Application.Current!.ApplicationLifetime is Avalonia.Controls.ApplicationLifetimes.IClassicDesktopStyleApplicationLifetime desktop
                ? desktop.MainWindow : null;
            var folder = await dlg.ShowAsync(window);
            if (string.IsNullOrEmpty(folder)) return;

            foreach (var r in Results)
            {
                if (r.DiffBitmap != null)
                {
                    var path = Path.Combine(folder, $"Row_{r.Row}_Diff.png");
                    r.DiffBitmap.Save(path, System.Drawing.Imaging.ImageFormat.Png);
                }
            }
        }

        public async Task PreviewAsync(object param)
        {
            if (param is ImageCompareResult r && r.DiffBitmap != null)
            {
                UpdatePreview(r);
            }
            await Task.CompletedTask;
        }

        private void UpdatePreview(ImageCompareResult? r = null)
        {
            var target = r ?? SelectedResult;
            if (target?.DiffBitmap == null)
            {
                SelectedPreviewImage = null;
                return;
            }

            using var ms = new MemoryStream();
            target.DiffBitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
            ms.Seek(0, SeekOrigin.Begin);
            SelectedPreviewImage = Bitmap.DecodeToWidth(ms, 1000);
        }
    }
}
