using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ExcelImageCompareTool.Services
{
    public class DiffRegion
    {
        public int MinX, MinY, MaxX, MaxY;
    }

    public class CompareResult
    {
        public int RowIndex;
        public bool HasDiff;
        public List<DiffRegion> Regions = new();
        public Bitmap? DiffBitmap;
    }

    public class ImageCompareService
    {
        public async Task<List<CompareResult>> CompareBatchAsync(
            List<(int RowIndex, byte[] OldImage, byte[] NewImage)> items,
            int maxDegreeOfParallelism = 4)
        {
            var bag = new ConcurrentBag<CompareResult>();

            await Parallel.ForEachAsync(items,
                new ParallelOptions { MaxDegreeOfParallelism = maxDegreeOfParallelism },
                async (item, _) =>
                {
                    var res = await CompareSingleAsync(item.RowIndex, item.OldImage, item.NewImage);
                    bag.Add(res);
                });

            return bag.OrderBy(r => r.RowIndex).ToList();
        }

        public async Task<CompareResult> CompareSingleAsync(int rowIndex, byte[] oldBytes, byte[] newBytes)
        {
            return await Task.Run(() =>
            {
                using var bmp1 = LoadBitmap(oldBytes);
                using var bmp2 = LoadBitmap(newBytes);

                var diffMap = PixelDiff_LockBits(bmp1, bmp2);
                var regions = FindRegions(diffMap);

                Bitmap? diffBmp = null;
                if (regions.Count > 0)
                {
                    diffBmp = DrawRegions(new Bitmap(bmp1), regions);
                }

                return new CompareResult
                {
                    RowIndex = rowIndex,
                    HasDiff = regions.Count > 0,
                    Regions = regions,
                    DiffBitmap = diffBmp
                };
            });
        }

        private Bitmap LoadBitmap(byte[] bytes)
        {
            using var ms = new MemoryStream(bytes);
            return new Bitmap(ms);
        }

        private bool[,] PixelDiff_LockBits(Bitmap bmp1, Bitmap bmp2)
        {
            int w = bmp1.Width, h = bmp1.Height;
            if (bmp2.Width != w || bmp2.Height != h) throw new Exception(\"图片尺寸不一致\");

            bool[,] diff = new bool[w, h];

            var rect = new Rectangle(0, 0, w, h);
            var d1 = bmp1.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
            var d2 = bmp2.LockBits(rect, ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);

            int stride1 = d1.Stride;
            int stride2 = d2.Stride;
            int bytesPerPixel = 4;

            unsafe
            {
                byte* p1 = (byte*)d1.Scan0;
                byte* p2 = (byte*)d2.Scan0;

                for (int y = 0; y < h; y++)
                {
                    byte* row1 = p1 + (y * stride1);
                    byte* row2 = p2 + (y * stride2);

                    for (int x = 0; x < w; x++)
                    {
                        int idx = x * bytesPerPixel;
                        byte b1 = row1[idx];
                        byte g1 = row1[idx + 1];
                        byte r1 = row1[idx + 2];
                        byte a1 = row1[idx + 3];

                        byte b2 = row2[idx];
                        byte g2 = row2[idx + 1];
                        byte r2 = row2[idx + 2];
                        byte a2 = row2[idx + 3];

                        if (r1 != r2 || g1 != g2 || b1 != b2 || a1 != a2)
                            diff[x, y] = true;
                    }
                }
            }

            bmp1.UnlockBits(d1);
            bmp2.UnlockBits(d2);

            return diff;
        }

        public List<DiffRegion> FindRegions(bool[,] diff)
        {
            int w = diff.GetLength(0), h = diff.GetLength(1);
            bool[,] visited = new bool[w, h];
            var regions = new List<DiffRegion>();

            int[,] dirs = new int[,]
            {
                {1,0},{-1,0},{0,1},{0,-1},
                {1,1},{1,-1},{-1,1},{-1,-1}
            };

            for (int x = 0; x < w; x++)
            {
                for (int y = 0; y < h; y++)
                {
                    if (!diff[x, y] || visited[x, y]) continue;

                    var q = new Queue<(int x, int y)>();
                    q.Enqueue((x, y));
                    visited[x, y] = true;

                    int minX = x, maxX = x, minY = y, maxY = y;

                    while (q.Count > 0)
                    {
                        var (cx, cy) = q.Dequeue();
                        for (int i = 0; i < dirs.GetLength(0); i++)
                        {
                            int nx = cx + dirs[i, 0];
                            int ny = cy + dirs[i, 1];

                            if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
                            if (!diff[nx, ny] || visited[nx, ny]) continue;

                            visited[nx, ny] = true;
                            q.Enqueue((nx, ny));

                            if (nx < minX) minX = nx;
                            if (nx > maxX) maxX = nx;
                            if (ny < minY) minY = ny;
                            if (ny > maxY) maxY = ny;
                        }
                    }

                    regions.Add(new DiffRegion { MinX = minX, MinY = minY, MaxX = maxX, MaxY = maxY });
                }
            }

            return regions;
        }

        public Bitmap DrawRegions(Bitmap baseImg, List<DiffRegion> regions)
        {
            using var g = Graphics.FromImage(baseImg);
            using var pen = new Pen(Color.Red, 2);

            foreach (var r in regions)
            {
                var rect = new Rectangle(
                    Math.Max(0, r.MinX - 1),
                    Math.Max(0, r.MinY - 1),
                    (r.MaxX - r.MinX) + 2,
                    (r.MaxY - r.MinY) + 2);

                g.DrawRectangle(pen, rect);
            }

            return baseImg;
        }
    }
}
