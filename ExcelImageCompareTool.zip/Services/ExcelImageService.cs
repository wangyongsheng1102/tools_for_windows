using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using System.Collections.Generic;
using System.IO;
using System;

namespace ExcelImageCompareTool.Services
{
    public static class ExcelImageService
    {
        public static Dictionary<int, byte[]> ExtractColumnImages(string excelPath, string sheetName, int colIndex)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            var result = new Dictionary<int, byte[]>();

            using var p = new ExcelPackage(new FileInfo(excelPath));
            var ws = p.Workbook.Worksheets[sheetName];
            if (ws == null) throw new Exception($"找不到 Sheet: {sheetName}");

            foreach (var d in ws.Drawings)
            {
                if (d is ExcelPicture pic)
                {
                    int row = pic.From.Row + 1;
                    int col = pic.From.Column + 1;

                    if (col == colIndex)
                    {
                        using var ms = new MemoryStream();
                        pic.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        result[row] = ms.ToArray();
                    }
                }
            }

            return result;
        }
    }
}
