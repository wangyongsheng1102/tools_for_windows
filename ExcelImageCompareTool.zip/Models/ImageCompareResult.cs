using System.Drawing;

namespace ExcelImageCompareTool.Models
{
    public class ImageCompareResult
    {
        public int Row { get; set; }
        public bool HasOldImage { get; set; }
        public bool HasNewImage { get; set; }
        public bool HasDiff { get; set; }
        public int RegionCount { get; set; }
        public Bitmap? DiffBitmap { get; set; }
    }
}
