# ExcelImageCompareTool

This is a generated Avalonia desktop tool template for comparing images embedded in Excel.
Features:
- EPPlus for Excel image extraction
- LockBits-based pixel compare
- Connected-component region merging
- Diff image generation (red rectangles)
- Multi-threaded batch processing
- Simple MVVM with ReactiveUI
- Preview and export

Run:
1. dotnet restore
2. dotnet run

Notes:
- Windows only (System.Drawing)
- Target: .NET 7.0
