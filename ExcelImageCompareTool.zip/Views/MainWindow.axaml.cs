using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Media.Imaging;
using System.IO;
using ExcelImageCompareTool.ViewModels;

namespace ExcelImageCompareTool.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Opened += async (_, __) => await (DataContext as MainWindowViewModel)!.InitializeAsync();
        }

        private async void OnSelectExcel(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog();
            dlg.Filters.Add(new FileDialogFilter { Name = "Excel 文件", Extensions = { "xlsx" } });
            var result = await dlg.ShowAsync(this);
            if (result != null && result.Length > 0)
            {
                (DataContext as MainWindowViewModel)!.Config.LastExcelPath = result[0];
                (DataContext as MainWindowViewModel)!.SaveConfig();
            }
        }

        private void OnExit(object sender, RoutedEventArgs e) => this.Close();
    }
}
