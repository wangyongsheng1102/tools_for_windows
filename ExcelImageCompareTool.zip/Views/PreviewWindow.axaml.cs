using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using System;

namespace ExcelImageCompareTool.Views
{
    public partial class PreviewWindow : Window
    {
        private double zoom = 1.0;
        public PreviewWindow()
        {
            InitializeComponent();
            this.PointerWheelChanged += OnWheel;
        }

        private void OnWheel(object? sender, PointerWheelEventArgs e)
        {
            zoom += e.Delta.Y * 0.1;
            if (zoom < 0.1) zoom = 0.1;
            PreviewImage.RenderTransform = new ScaleTransform(zoom, zoom);
        }
    }
}
